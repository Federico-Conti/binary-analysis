#!/bin/bash
docker run -d --rm -p 127.0.0.1:8004:6000 --name tuctf2019_printfun -it zxgio/tuctf2019_printfun
