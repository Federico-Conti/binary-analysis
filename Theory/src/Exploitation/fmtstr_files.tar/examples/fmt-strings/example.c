#include <stdio.h>

char other_secret[] = "This secret is not referenced on the stack...\n";

int main()
{
	char *s_str = "This is a secret string! (pointer on the stack)\n";
	long s_int = 0xc0ffee;
	char name[16];
	printf("What's your name? ");
	fflush(stdout);
	fgets(name, sizeof(name), stdin);
	printf("Hi, ");
	printf(name);
}
